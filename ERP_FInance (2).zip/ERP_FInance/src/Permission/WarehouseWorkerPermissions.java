package Permission;

public interface WarehouseWorkerPermissions {
    void addProduct();
}
