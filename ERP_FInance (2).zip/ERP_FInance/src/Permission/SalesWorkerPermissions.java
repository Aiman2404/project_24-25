package Permission;

public interface SalesWorkerPermissions {
    void removeProduct();
}
