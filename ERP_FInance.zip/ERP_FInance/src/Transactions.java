import java.sql.*;

public class Transactions {

    public void SellTrans(){

    }
    public void WareTrans(){

    }

}
