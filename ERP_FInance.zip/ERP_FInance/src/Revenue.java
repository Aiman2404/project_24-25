public class Revenue {
}
