public interface Users {

        String getUsername();
        String getPassword();
        String getRole();
        String getDepartment();
        void performFunctionality();





}
