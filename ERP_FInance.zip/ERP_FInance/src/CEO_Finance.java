public class CEO_Finance extends CEO{
    public CEO_Finance(String id, String username, String password, String role, String department) {
        super(id, username, password, role, department);
    }

    public CEO_Finance() {
    }


    @Override
    public void performFunctionality() {

    }
}
