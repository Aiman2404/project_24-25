public class Expenses {
}
