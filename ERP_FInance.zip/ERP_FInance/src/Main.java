public class Main {
    public static void main(String[] args) {
        myJDBC j=new myJDBC();
        j.connectionSQL();

        LogIn log=new LogIn();
        log.login();


    }
}
